module HTTP.client {
    requires java.net.http;
}